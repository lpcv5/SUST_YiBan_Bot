import numpy
import xmltodict as xmltodict
from cssselect import xpath
from lxml import etree
import cv2
from PIL import Image

import goto_checkpage
import util
import json
import re


# html = etree.parse('min.html', etree.HTMLParser())
# url_list = html.xpath('/html/body/div[@class="weui-grids grids-small"]/a/@href')
# elem = html.xpath("/html/body/div[@class='weui-grids grids-small']/a/p/text()")
# url = {
#     "url_holiday": url_list[elem.index("寒假信息上报")],
#     "url_morn": url_list[elem.index("晨检上报")],
#     "url_noon": url_list[elem.index("午检上报")]
#        }
# with open('url.json', 'w') as date:
#     json.dump(url, date)


ssid = '1c7694732ce7a5df019d1eadc2c7931d'
for i in range(5017, 10000):
    util.get_yzm(ssid)
    img = Image.open('yzm.jpg')
    dst = util.image_binarization(img)
    cv2.imwrite('./codeimg/binary' + str(i) + '.jpg', dst)
