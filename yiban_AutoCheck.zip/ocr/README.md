# 用CNN识别验证码| python识别验证码| 训练验证码模型



适用于无深度学习基础的朋友，只需要编写getimg.py相关路径即可

有问题可以提issue

## 本项目使用方法：

[使用方法](https://mp.weixin.qq.com/s/wUpKG7uifU_aj8oWYEPqqQ)


有关于验证码生成可以看我这两篇文章：

[验证码破解没有训练集？我教你生成一万个！](https://mp.weixin.qq.com/s/B_kPiDRR1UVT2xj9gNpU1Q)

[不得不说这个验证码生成库，牛逼了！](https://mp.weixin.qq.com/s/Vb2ekbaCFtw_jeX7jFiqDA)

![image](https://github.com/hellokuls/cnnyzm/blob/master/erweima.jpg)

